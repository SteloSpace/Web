Contributing
====
All contributions welcome, I don't really have much time to spend on this right at the moment :)
